let livro = {
    titulo: "O Guia do Mochileiro das Galáxias",
    autor: "Douglas Adams",
    anoPublicacao: 1979,
    genero: "Ficção Científica",
    editora: "Pan Books"
};

const anoAtual = new Date().getFullYear();

livro.idadePublicacao = anoAtual - livro.anoPublicacao;

delete livro.editora;

console.log(livro);